# EasyPhones Backend — PhoneBecho API

Express + TypeScript + MySQL2 backend for the PhoneBecho Flutter marketplace app.

---

## Setup

```bash
cp .env.example .env
# Fill in DB credentials and JWT secrets

npm install
npm run db:migrate     # creates all tables
npm run db:seed        # optional demo user
npm run dev            # ts-node-dev dev server
```

---

## API Reference

| Method | Endpoint               | Auth    | Description                          |
|--------|------------------------|---------|--------------------------------------|
| POST   | /api/auth/register     | —       | Create account                       |
| POST   | /api/auth/login        | —       | Login, get tokens                    |
| POST   | /api/auth/refresh      | —       | Rotate refresh token                 |
| POST   | /api/auth/logout       | Bearer  | Revoke refresh token                 |
| GET    | /api/auth/me           | Bearer  | Get current user                     |
| GET    | /api/ads               | —       | Browse ads (paginated, filterable)   |
| GET    | /api/ads/my            | Bearer  | My ads (all, incl. inactive)         |
| GET    | /api/ads/:id           | —       | Single ad                            |
| POST   | /api/ads               | Bearer  | Create ad                            |
| PUT    | /api/ads/:id           | Bearer  | Update ad (owner only)               |
| DELETE | /api/ads/:id           | Bearer  | Soft-delete ad (owner only)          |
| GET    | /api/meta              | —       | Brands, cities, conditions           |
| POST   | /api/upload/presign    | Bearer  | Get S3 presigned upload URLs         |
| GET    | /api/users/:id         | —       | Public profile + ad count            |
| PUT    | /api/users/me          | Bearer  | Update name/phone                    |
| PUT    | /api/users/me/avatar   | Bearer  | Update avatar URL                    |
| PUT    | /api/users/me/password | Bearer  | Change password                      |

---

## GET /api/ads — Query Parameters

| Param      | Type    | Default | Description                                  |
|------------|---------|---------|----------------------------------------------|
| page       | int     | 1       | Page number                                  |
| limit      | int     | 20      | Items per page (max 50)                      |
| q          | string  | —       | Full-text search (title, brand, model, city) |
| brand      | string  | —       | Filter by brand (case-insensitive)           |
| condition  | string  | —       | brandNew / likeNew / good / fair             |
| city       | string  | —       | Filter by city (case-insensitive)            |
| min_price  | number  | —       | Min price in PKR                             |
| max_price  | number  | —       | Max price in PKR                             |
| sort       | string  | newest  | newest / oldest / price_asc / price_desc     |

---

## Notes

- **No Prisma** — raw `mysql2/promise` pool with typed helpers in `src/config/db.ts`
- **No repository layer** — services call the DB directly
- **Refresh token rotation** — every `/auth/refresh` call revokes the old token and issues a new one
- **Soft deletes** — `DELETE /ads/:id` sets `is_active = false`, never removes the row
- **seller_name denormalization** — stored on each ad; synced when user updates their name
- **Image uploads** — S3 presigned URL flow; the API never receives image bytes
- **Full-text search** — MySQL `FULLTEXT` index on `title, brand, model, city` with `BOOLEAN MODE`
